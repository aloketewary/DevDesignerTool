export interface MainTabs {
    label: string;
    content: string;
    href: string;
}
