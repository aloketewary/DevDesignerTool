export class Constants {
    public static readonly MAIN_TABS = 'main_tabs';
    public static readonly LOCALE = 'locale-';
    public static readonly ICONS_COLLECTION = 'icons';
}
