import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-fonts',
  templateUrl: './fonts.component.html',
  styleUrls: ['./fonts.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FontsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
