export interface IconsData {
    codepoint: string;
    group_id: string;
    id: string;
    keywords: Array<string>;
    length: number;
    ligature: string;
    name: string;
}
