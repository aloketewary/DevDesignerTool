import { ScrollableDirective } from './scrollable.directive';

describe('ScrollableDirective', () => {
  it('should create an instance', () => {
    const directive = new ScrollableDirective();
    expect(directive).toBeTruthy();
  });
});
