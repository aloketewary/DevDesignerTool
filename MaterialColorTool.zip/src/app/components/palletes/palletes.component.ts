import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-palletes',
  templateUrl: './palletes.component.html',
  styleUrls: ['./palletes.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PalletesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
